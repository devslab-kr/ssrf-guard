import manifest from './manifest.mjs';
import {createFamilyFontAPI} from './runtime.mjs';
export {FAMILY_FONT_CACHE_CONTROL} from './runtime.mjs';
export const {fontManifest,getFontHeadLinks,getFontAssetHeaders,fontAssetHeaders,withFamilyFontCache,getBundleFontPreloadLinks,getBundleFontAssetHeaders,isFamilyFontAssetRequest}=createFamilyFontAPI(manifest);
