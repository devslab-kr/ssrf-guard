# DDS family fonts

Private generated font-only distribution from DDS. Do not edit consumer copies. Regenerate from the DDS source reference and verify the archive SRI. No framework, runtime dependency, lifecycle hook, or npm publication.

Use fonts.css and the Vite entry in bundled apps. Run `node export.mjs --out-dir DIR --base-url /PREFIX --head-output FILE [--monospace]` for static/Next/MkDocs. Source provenance, face SHA256, licenses, and preload information are in manifest.json.
