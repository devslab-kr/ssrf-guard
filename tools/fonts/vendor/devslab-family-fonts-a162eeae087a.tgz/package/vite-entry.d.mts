import type {FontLink,FontOptions} from './runtime.mjs';
export declare function getFontPreloadLinks(options?:FontOptions):FontLink[];
