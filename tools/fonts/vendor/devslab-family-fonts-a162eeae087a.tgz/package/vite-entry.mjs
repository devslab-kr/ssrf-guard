import font0 from "./fonts/geist-geist-latin-wght-normal-19f9c92546aa.woff2?url";
import font1 from "./fonts/pretendard-PretendardVariable-9599f12fd42f.woff2?url";
import font2 from "./fonts/geist-mono-geist-mono-latin-wght-normal-684ad5b531f8.woff2?url";
import manifest from './manifest.mjs';
import {fontPreloadLinksFromUrls} from './runtime.mjs';
const urls={"geist/geist-latin-wght-normal.woff2":font0,"pretendard/PretendardVariable.woff2":font1,"geist-mono/geist-mono-latin-wght-normal.woff2":font2};
export function getFontPreloadLinks({monospace=false,format='html'}={}){return fontPreloadLinksFromUrls([...manifest.preload.default,...(monospace?manifest.preload.monospace:[])].map(id=>urls[id]),{format});}
